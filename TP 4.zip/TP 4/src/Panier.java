import java.util.ArrayList;

public class Panier {
    ArrayList <Produit> Liste;
    int poidsTotal = 0;
    static int id = 0;

    public Panier () {
        Liste = new ArrayList <> ();
        id = id +1;
    }
    public int getId(){
        return id;
    }
    public void ajoutProduit (Produit p) {
        poidsTotal = poidsTotal + p.getPoids();
        int test = poidsTotal;
        if (test <= 10000){
            Liste.add(p);
        }
        else {
            System.out.println("erreur : panier trop lourd");
        }
    }
    public boolean supprimerProduit(Produit p) {
        int pos;
        if (Liste.contains(p)) {
            pos = Liste.indexOf(p);
            Liste.remove(pos);
            poidsTotal = poidsTotal - p.getPoids();
            return true;
        }
        else {
            return false;
        }
    }
    public int nombreProduit (){
        if (Liste.isEmpty()) {
            return 0;
        }
        else {
            return Liste.size() - 1;
        }
    }
    //L'ordre de grandeur de prixTotal() est de Liste.size() + 2
    public String prixTotal () {
        int i;
        int somme = 0;
        for (i=0; i < Liste.size(); i++) {
            somme += Liste.get(i).prix;
        }
        return (String.format("%d.%02d", somme / 100 , somme % 100));
    }
}
