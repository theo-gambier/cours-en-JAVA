public class Produit {
    String name;
    Long prix;
    int poids;

    public Produit (String s,Long p, int po) {
        name =s;
        prix = p;
        poids = po;
    }
    public String getName () {
        return name;
    }
    public Long getPrix () {
        return prix;
    }
    public int getPoids () {
        return poids;
    }
    public String toString () {
        return name + " : " + String.format("%d.%02d", prix / 100 , prix % 100) + " €";
    }


}
